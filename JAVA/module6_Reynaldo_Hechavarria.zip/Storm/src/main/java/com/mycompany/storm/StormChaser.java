/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.storm;

/**
 *
 * @author rhechavarria
 */
import java.io.*;
import java.util.*;

public class StormChaser {

    public static void main(String[] args) {
        ArrayList<Storm> list = new ArrayList<>();  // list to hold qualifying storms
        Storm newStorm;
        Storm current;
        int total = 0;       // total number of storm records

        // Variables to track key statistics
        int maxWind = 0;
        int minPressure = Integer.MAX_VALUE;

        Scanner in;

        try {
            System.out.println("Opening hurricane data file...");
            in = new Scanner(new File("hurricane.data"));
        }
        catch(FileNotFoundException e) {
            System.err.println("File not found.");
            return;
        }

        System.out.println("File opened successfully...");
        System.out.println("Reading file...");

        while (in.hasNext()) {
            int year = in.nextInt();
            int month = in.nextInt();
            int day = in.nextInt();
            int hour = in.nextInt();
            int id = in.nextInt();          // additional data, not used
            String name = in.next();        // storm name
            double lat = in.nextDouble();   // latitude (skipped)
            double lon = in.nextDouble();   // longitude (skipped)
            int wind = in.nextInt();        // wind speed (in knots)
            int pressure = in.nextInt();    // pressure (in millibars)

            int beginDate = year * 10000 + month * 100 + day;
            int duration = 6;  // fixed duration of 6 hours

            newStorm = new Storm(beginDate, duration, name, wind, pressure);
            current = newStorm;
            total++;

            if (current.getWind() > maxWind) {
                maxWind = current.getWind();
            }
            if (current.getPressure() < minPressure) {
                minPressure = current.getPressure();
            }

            if (current.getCategory() >= 3) {
                list.add(current);
            }
        }

        System.out.println("Total storms recorded: " + total);
        System.out.println("Maximum wind speed: " + maxWind + " MPH");
        System.out.println("Minimum pressure: " + minPressure + " mb");
        System.out.println("Hurricanes with category 3 and above: " + list.size());

        Collections.sort(list, (s1, s2) -> {
            if (s2.getCategory() != s1.getCategory()) {
                return s2.getCategory() - s1.getCategory();
            }
            return s2.getWind() - s1.getWind();
        });

        System.out.println("\nMost Powerful Storms:");
        System.out.println("----------------------");
        int displayCount = Math.min(list.size(), 10);
        for (int i = 0; i < displayCount; i++) {
            System.out.println(list.get(i));
        }

        in.close();
    }
}