/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.storm;

/**
 *
 * @author rhechavarria
 */
public class Storm {
    private final double KnotsToMPH = 1.15;

    private int beginDate;
    private int duration;
    private String name;
    private int category;
    private int wind;
    private int pressure;

    public Storm(int bdate, int dur, String sname, int w, int p) {
        beginDate = bdate;
        duration = dur;
        name = sname;
        wind = (int)(w * KnotsToMPH);
        pressure = p;
        saffirSimpson();
    }

    public void saffirSimpson() {
        if (wind >= 157)
            category = 5;
        else if (wind >= 130)
            category = 4;
        else if (wind >= 111)
            category = 3;
        else if (wind >= 96)
            category = 2;
        else if (wind >= 74)
            category = 1;
        else
            category = 0;
    }

    public int getWind() { return wind; }
    public int getPressure() { return pressure; }
    public int getCategory() { return category; }
    public String getName() { return name; }
    public int getBeginDate() { return beginDate; }
    public int getDuration() { return duration; }

    @Override
    public String toString() {
        return name + " | Date: " + beginDate
            + " | Wind: " + wind + " MPH"
            + " | Pressure: " + pressure + " mb"
            + " | Category: " + category;
    }
}